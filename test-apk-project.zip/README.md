# Test

Project ini dibuat otomatis dari menu "Buat APK".

## Cara mendapatkan file .apk ASLI
1. Buat repository baru (kosong) di GitHub.
2. Upload/push semua isi ZIP ini ke repository tersebut.
3. Buka tab **Actions** di repository — workflow "Build APK" akan berjalan
   otomatis dan mengompilasi APK memakai Android SDK asli (±1-3 menit).
4. Setelah selesai (centang hijau), klik run tersebut lalu unduh artifact
   **app-debug-apk** — di dalamnya ada file `app-debug.apk` yang bisa
   langsung dipasang di HP Android.

Ini APK asli hasil kompilasi Android SDK sungguhan, bukan simulasi.
